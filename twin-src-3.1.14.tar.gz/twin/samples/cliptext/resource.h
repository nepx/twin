/*{{NO_DEPENDENCIES}}
*/
/* App Studio generated include file.
*/
/* Used by CLIPTEXT.RC
*/
/*
*/
#define IDM_ABOUT                       100
#define IDM_NEW                         101
#define _APS_NEXT_COMMAND_VALUE         101
#define _APS_NEXT_SYMED_VALUE           101
#define IDM_OPEN                        102
#define _APS_NEXT_RESOURCE_VALUE        102
#define IDM_SAVE                        103
#define IDM_SAVEAS                      104
#define IDM_PRINT                       105
#define IDM_EXIT                        106
#define IDM_UNDO                        200
#define IDM_CUT                         201
#define IDM_COPY                        202
#define IDM_PASTE                       203
#define IDM_CLEAR                       204
#define _APS_NEXT_CONTROL_VALUE         1000
