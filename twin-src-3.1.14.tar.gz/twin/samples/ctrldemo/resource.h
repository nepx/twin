/* @(#)resource.h	1.1 10/23/96 12:54:35 /users/sccs/src/samples/ctrldemo/s.resource.h */

#define IDI_ICON1                       100 



#define IDB_TOOLBAR			200



#define IDM_ABOUT			300	

#define IDM_EXIT                        301 

#define IDM_UPDOWN                      302 

#define IDM_PROPSHEET		303



#define IDD_UPDOWNTEST                  400

#define IDD_TAB1                        401

#define IDD_TAB2                        402

#define IDD_TAB3                        403



#define IDS_TITLE			500



#define IDE_BUDDY			600



#define IDC_CHECK1                    	700

#define IDC_CHECK2                     	701

#define IDC_CHECK3                      702

#define IDC_CHECK4			703

#define IDC_BUTTON1 			704

#define IDC_BUTTON2			705

#define IDC_BUTTON3                     706

#define IDC_BUTTON4                     707

#define IDC_RADIO1                      708

#define IDC_RADIO2                      709

#define IDC_RADIO3                      710

#define IDC_RADIO4			711

#define IDC_EDIT1                       712

#define IDC_LIST1			713

#define IDC_COMBO1			714

#define IDC_BUTTON5			715

#define IDC_BUTTON6			716



#define ID_UPDOWN		        800

#define ID_TOOLBAR  		        801

#define ID_TEST				802

#define IDCANCELTEST		803



#define MAX_SPIN			10

#define MIN_SPIN			1



#define IDC_STATIC                      -1



/* Next default values for new objects

*/ 

#ifdef APSTUDIO_INVOKED

#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        150

#define _APS_NEXT_COMMAND_VALUE         40018

#define _APS_NEXT_CONTROL_VALUE         1073

#define _APS_NEXT_SYMED_VALUE           101

#endif

#endif




