/*
 *	windemo.c -- header file for windemo
 *
 *	@(#)windemo.h	1.1 2/13/96 13:08:21 /users/sccs/src/samples/windemo/s.windemo.h
 *
 *	Copyright (c) 1995-1996, Willows Software Inc.  All rights reserved.
 *
 */

#define IDM_ABOUT	102
#define IDM_EXIT	103
#define  IDM_MOUSEEVENTS	201
#define  IDM_KEYBOARDEVENTS 	202

#define IDS_TITLE	200

#define IDI_ICON1	201
