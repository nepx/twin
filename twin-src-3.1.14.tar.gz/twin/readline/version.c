const char version_string[] = "1.234";


static char foobar[]="foobar";

const char * foo_string = foobar;
