    
#include "ModTable.h"

extern int LoadTwinModDscr(int,char **, MODULEDSCR *);
extern int LoadTwinLibInit();

#define TWINLIBDECL

#define TWINLIBINIT
#define TWINLIBEXIT

