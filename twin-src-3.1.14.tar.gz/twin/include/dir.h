/*  dir.h	1.1 */

#ifndef DIR_H
#define	DIR_H

/*
 * For now, this file is intentionally left blank,
 * it is an empty placeholder to support source ports.
 */
#include "mfs_dir.h"

#endif /* DIR_H */

