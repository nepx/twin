/* Do not modify this file -- it is automatically generated! */

#ifndef __WINE_DEBUGTOOLS_H
#include "debugtools.h"
#endif

/* Definitions for channels identifiers */
#define dbch_API 0
#define dbch_BIN 1
#define dbch_DOS 2
#define dbch_GDI 3
#define dbch_INT 4
#define dbch_KERNEL 5
#define dbch_LIB 6
#define dbch_MEM 7
#define dbch_MSG 8
#define dbch_SYS 9
#define dbch_USER 10
#define dbch_X11 11
#define dbch_profile 12
#define dbch_string 13
#define dbch_uitools 14
/* Definitions for classes identifiers */
#define dbcl_CONSOLE 0
#define dbcl_TRACE 1
#define dbcl_WARN 2
#define dbcl_STUB 3
#define dbcl_FIXME 4
#define dbcl_FAIL 5
#define dbcl_CALL 6
#define dbcl_RET 7
