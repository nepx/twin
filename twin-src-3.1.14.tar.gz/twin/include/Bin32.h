
typedef struct {
	unsigned long (*faddr)();
	unsigned long (*maddr)();
	char *lpstr;
} MAPTABLE;
