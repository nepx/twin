
DWORD DrvIPCInit(LPARAM,LPARAM,LPVOID);
DWORD DrvImagesInit(LPARAM, LPARAM, LPVOID);
DWORD DrvCursorSetClipCursor(LPARAM,LPARAM,LPVOID);
DWORD DrvColorsInit(LPARAM,LPARAM,LPVOID);
DWORD DrvKeyboardInit(LPARAM,LPARAM,LPVOID);
DWORD DrvTextInit(LPARAM,LPARAM,LPVOID);

DWORD DrvSystemTab(void);
DWORD DrvRegionsTab(void);
DWORD DrvImagesTab(void);
DWORD DrvGraphicsTab(void);
DWORD DrvDCTab(void);
DWORD DrvTextTab(void);
DWORD DrvWindowsTab(void);
DWORD DrvIPCTab(void);
DWORD DrvCursorTab(void);
DWORD DrvKeyboardTab(void);
DWORD DrvColorsTab(void);
DWORD DrvEventsTab(void);
DWORD DrvWinsockTab(void);
DWORD DrvConfigTab(void);
DWORD DrvTimeTab(void);
DWORD DrvPrintingTab(void);
DWORD DrvFilesTab(void);

