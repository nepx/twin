
int
advapi32End()
{
	return 0;
}

